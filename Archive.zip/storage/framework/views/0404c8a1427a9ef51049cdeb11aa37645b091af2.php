<?php $__env->startSection('title','Hải Sản Tên Lửa'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('component.cart_modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="services-breadcrumb">
		<div class="agile_inner_breadcru    mb">
			<div class="container">
				<ul class="w3_short">
					<li>
						<a href="<?php echo e(route('home')); ?>">Trang Chủ</a>
						<i>|</i>
					</li>
					<li>Về Chúng Tôi</li>
				</ul>
			</div>
		</div>
	</div>
<div class="welcome">
		<div class="container">
			<!-- tittle heading -->
			<h3 class="tittle-w3l">Nhà Hàng Hải Sản Tên Lửa Chúng Tôi
				<span class="heading-style">
					<i></i>
					<i></i>
					<i></i>
				</span>
			</h3>
			<!-- //tittle heading -->
        <div class="w3l-welcome-info">
            <?php $__currentLoopData = $about; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-sm-6 col-xs-6 welcome-grids">
					<div class="welcome-img">
						<img src="<?php echo e(asset('image/slide/'.$item->image)); ?>" class="img-responsive zoom-img" alt="">
                    </div>
                    <p><?php echo e($item->info); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<div class="clearfix"> </div>
			</div>

		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>