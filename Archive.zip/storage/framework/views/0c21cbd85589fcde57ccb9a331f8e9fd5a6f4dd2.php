<?php $__env->startSection('title','Hải Sản Tên Lửa'); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('component.cart_modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="ads-grid">
        <div class="container">
            <!-- tittle heading -->
            <h3 class="tittle-w3l">Tất Cả Sản Phẩm
                <span class="heading-style">
					<i></i>
					<i></i>
					<i></i>
				</span>
            </h3>
            <!-- //tittle heading -->
            <!-- product left -->

            <!-- //product left -->
            <!-- product right -->
            <div class="agileinfo-ads-display col-md-12">
                <div class="wrapper">
                    <!-- first section (nuts) -->
                     <?php if($categorySelling->status == 1): ?>
                    <div class="product-sec1">

                        <h3 class="heading-tittle"><?php echo e($categorySelling->name); ?></h3>
                        <?php $__currentLoopData = $productSelling; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $product->product_variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($variant->status == 1 && $variant->image): ?>
                        <input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">
                        <div class="col-md-4 product-men">
                            <div class="men-pro-item simpleCart_shelfItem">
                                <div class="men-thumb-item" id="<?php echo e($variant->id); ?>">
                                    <img  class="image_cart" style="width:250px;height:200px" src="<?php echo e(asset('image/product/'.$variant->image)); ?>"  id="<?php echo e($variant->image); ?>" alt="">
                                    <div class="men-cart-pro">
                                        <div class="inner-men-cart-pro">
                                            <a href="<?php echo e(route('detail_product',$product->slug)); ?>" class="link-product-add-cart">Chi Tiết</a>
                                        </div>
                                    </div>
                                    <span class="product-new-top"><?php echo e($product->getHot()); ?></span>
                                </div>
                                <div class="item-info-product ">
                                    <h4 class="name_cart" id="<?php echo e($product->name); ?>">
                                        <a href="single.html"><?php echo e($product->name); ?></a>
                                    </h4>
                                    <div class="info-product-price size_cart" id="<?php echo e($variant->size); ?>">
                                        <span class="item_price" id="<?php echo e($variant->getPriceCart()); ?>">Giá :  <?php echo e($variant->getPrice()); ?></span>
                                    </div>
                                    <div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
                                        <?php if($variant->getPrice() != "Liên Hệ"): ?>
                                         <button type="button" name="addToCart" data-url="<?php echo e(route('cartAjax')); ?>" class="btn btn-info btn-lg addToCart" data-toggle="modal" >Thêm Vào Giỏ Hàng</button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="clearfix"></div>
                        <?php endif; ?>

                    </div>
                    <!-- //first section (nuts) -->
                    <!-- second section (nuts special) -->
                    <!-- //second section (nuts special) -->
                    <!-- third section (oils) -->
                    <div class="product-sec1">
                        <h3 class="heading-tittle"><?php echo e($categorySpecial->name); ?></h3>
                        <?php $__currentLoopData = $productSpecial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $item->product_variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($variant->status == 1 && $variant->image): ?>
                        <div class="col-md-4 product-men">
                            <div class="men-pro-item simpleCart_shelfItem">
                                <div class="men-thumb-item">
                                    <img style="width:250px;height:200px" src="<?php echo e(asset('image/product/'.$variant->image)); ?>" alt="">
                                    <div class="men-cart-pro">
                                        <div class="inner-men-cart-pro">
                                            <a href="<?php echo e(route('detail_product',$product->slug)); ?>" class="link-product-add-cart">Chi Tiết</a>
                                        </div>
                                    </div>
                                    <span class="product-new-top"><?php echo e($product->getHot()); ?></span>
                                </div>
                                <div class="item-info-product ">
                                    <h4>
                                        <a href="single.html"><?php echo e($product->name); ?></a>
                                    </h4>
                                    <div class="info-product-price">
                                        <span class="item_price">Giá : <?php echo e($variant->getPrice()); ?></span>
                                    </div>
                                    <div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
                                        <form action="#" method="post">
                                            <fieldset>
                                                <input type="hidden" name="id"    id="<?php echo e($variant->id); ?>" value="<?php echo e($variant->id); ?>" />
                                                <input type="hidden" name="image" id="<?php echo e($variant->image); ?>" value="<?php echo e($variant->image); ?>" />
                                                <input type="hidden" name="name"  id="<?php echo e($product->name); ?>" value="<?php echo e($product->name); ?>"/>
                                                <input type="hidden" name="price" id="<?php echo e($variant->getPriceCart()); ?>" value="<?php echo e($variant->getPriceCart()); ?>" />
                                                <input type="hidden" name="size" id="<?php echo e($variant->size); ?>" value="<?php echo e($variant->size); ?>" />
                                                
                                            </fieldset>
                                        </form>
                                        <?php if($variant->getPrice() != "Liên Hệ"): ?>
                                         <button type="button" name="addToCart" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Thêm Vào Giỏ Hàng</button>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="clearfix"></div>
                    </div>
                    <!-- //third section (oils) -->
                    <!-- fourth section (noodles) -->
                    <div class="product-sec1">
                        <h3 class="heading-tittle">Pasta & Noodles</h3>
                        <div class="col-md-4 product-men">
                            <div class="men-pro-item simpleCart_shelfItem">
                                <div class="men-thumb-item">
                                    <img src="images/mk7.jpg" alt="">
                                    <div class="men-cart-pro">
                                        <div class="inner-men-cart-pro">
                                            <a href="single.html" class="link-product-add-cart">Quick View</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="item-info-product ">
                                    <h4>
                                        <a href="single.html">Yippee Noodles, 65g</a>
                                    </h4>
                                    <div class="info-product-price">
                                        <span class="item_price">$15.00</span>
                                        <del>$25.00</del>
                                    </div>
                                    <div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
                                        <form action="#" method="post">
                                            <fieldset>
                                                <input type="hidden" name="cmd" value="_cart" />
                                                <input type="hidden" name="add" value="1" />
                                                <input type="hidden" name="business" value=" " />
                                                <input type="hidden" name="item_name" value="YiPPee Noodles, 65g" />
                                                <input type="hidden" name="amount" value="15.00" />
                                                <input type="hidden" name="discount_amount" value="1.00" />
                                                <input type="hidden" name="currency_code" value="USD" />
                                                <input type="hidden" name="return" value=" " />
                                                <input type="hidden" name="cancel_return" value=" " />
                                                <input type="submit" name="submit" value="Add to cart" class="button" />
                                            </fieldset>
                                        </form>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 product-men">
                            <div class="men-pro-item simpleCart_shelfItem">
                                <div class="men-thumb-item">
                                    <img src="images/mk8.jpg" alt="">
                                    <div class="men-cart-pro">
                                        <div class="inner-men-cart-pro">
                                            <a href="single.html" class="link-product-add-cart">Quick View</a>
                                        </div>
                                    </div>
                                    <span class="product-new-top">New</span>

                                </div>
                                <div class="item-info-product ">
                                    <h4>
                                        <a href="single.html">Wheat Pasta, 500g</a>
                                    </h4>
                                    <div class="info-product-price">
                                        <span class="item_price">$98.00</span>
                                        <del>$120.00</del>
                                    </div>
                                    <div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
                                        <form action="#" method="post">
                                            <fieldset>
                                                <input type="hidden" name="cmd" value="_cart" />
                                                <input type="hidden" name="add" value="1" />
                                                <input type="hidden" name="business" value=" " />
                                                <input type="hidden" name="item_name" value="Wheat Pasta, 500g" />
                                                <input type="hidden" name="amount" value="98.00" />
                                                <input type="hidden" name="discount_amount" value="1.00" />
                                                <input type="hidden" name="currency_code" value="USD" />
                                                <input type="hidden" name="return" value=" " />
                                                <input type="hidden" name="cancel_return" value=" " />
                                                <input type="submit" name="submit" value="Add to cart" class="button" />
                                            </fieldset>
                                        </form>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 product-men">
                            <div class="men-pro-item simpleCart_shelfItem">
                                <div class="men-thumb-item">
                                    <img src="images/mk9.jpg" alt="">
                                    <div class="men-cart-pro">
                                        <div class="inner-men-cart-pro">
                                            <a href="single.html" class="link-product-add-cart">Quick View</a>
                                        </div>
                                    </div>
                                    <span class="product-new-top">New</span>

                                </div>
                                <div class="item-info-product ">
                                    <h4>
                                        <a href="single.html">Chinese Noodles, 68g</a>
                                    </h4>
                                    <div class="info-product-price">
                                        <span class="item_price">$11.99</span>
                                        <del>$15.00</del>
                                    </div>
                                    <div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
                                        <form action="#" method="post">
                                            <fieldset>
                                                <input type="hidden" name="cmd" value="_cart" />
                                                <input type="hidden" name="add" value="1" />
                                                <input type="hidden" name="business" value=" " />
                                                <input type="hidden" name="item_name" value="Chinese Noodles, 68g" />
                                                <input type="hidden" name="amount" value="11.99" />
                                                <input type="hidden" name="discount_amount" value="1.00" />
                                                <input type="hidden" name="currency_code" value="USD" />
                                                <input type="hidden" name="return" value=" " />
                                                <input type="hidden" name="cancel_return" value=" " />
                                                <input type="submit" name="submit" value="Add to cart" class="button" />
                                            </fieldset>
                                        </form>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <!-- //fourth section (noodles) -->
                </div>
            </div>
            <!-- //product right -->
        </div>
    </div>
    <!-- //top products -->
    <!-- special offers -->
    <div class="featured-section" id="projects">
        <div class="container">
            <!-- tittle heading -->

            <h3 class="tittle-w3l"><?php echo e($categorySlide->name); ?>

                <span class="heading-style">
					<i></i>
					<i></i>
					<i></i>
				</span>
            </h3>
            <!-- //tittle heading -->
            <div class="content-bottom-in">
                <ul id="flexiselDemo1">
                    <?php $__currentLoopData = $productSlide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $product->product_variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($variant->status == 1 && $variant->image): ?>
                    <li>
                        <div class="w3l-specilamk">
                            <div class="speioffer-agile">
                                <a href="single.html">
                                    <img style="width:280px;height:150px" src="<?php echo e(asset('image/product/'.$variant->image)); ?>" alt="">
                                </a>
                            </div>
                            <div class="product-name-w3l">
                                <h4>
                                    <a href="single.html"><?php echo e($product->name); ?></a>
                                </h4>
                                <div class="w3l-pricehkj">
                                    <h6>Giá : <?php echo e($variant->getPrice()); ?></h6>
                                </div>
                                <div class="snipcart-details top_brand_home_details item_add single-item hvr-outline-out">
                                    <form action="#" method="post">
                                        <fieldset>
                                            <input type="hidden" name="cmd" value="_cart" />
                                            <input type="hidden" name="add" value="1" />
                                            <input type="hidden" name="business" value=" " />
                                            <input type="hidden" name="item_name" value="Aashirvaad, 5g" />
                                            <input type="hidden" name="amount" value="220.00" />
                                            <input type="hidden" name="discount_amount" value="1.00" />
                                            <input type="hidden" name="currency_code" value="USD" />
                                            <input type="hidden" name="return" value=" " />
                                            <input type="hidden" name="cancel_return" value=" " />
                                            
                                        </fieldset>
                                    </form>
                                    <?php if($variant->getPrice() != "Liên Hệ"): ?>
                                         <button type="button" name="addToCart" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Thêm Vào Giỏ Hàng</button>
                                        <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </li>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>