<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Products\Product;
use App\Models\Products\ProductVariant;
use App\Models\Category;

class ApiAndroid extends Controller
{
    public function getProduct(){
        $products = Product::with('product_variants')->whereStatus(1)->get();
        return response()->json($products, 200);
    }


    public function getCategory(){
        $category = Category::whereStatus(1)->get();

        return response()->json($category,200);
    }
}
